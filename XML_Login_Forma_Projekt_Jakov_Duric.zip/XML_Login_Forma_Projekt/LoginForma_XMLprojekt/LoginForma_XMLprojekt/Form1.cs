﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;
using System.IO;

namespace LoginForma_XMLprojekt
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public string FromXML_user = "e";
        public string FromXML_pwd = "e";
        public string FromXML_ime = "e";
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string user = username.Text;
            string pwd = password.Text;

            XDocument doc = XDocument.Load(Application.StartupPath.ToString() + @"\Korisnici.xml");
            var selected_user = from x in doc.Descendants("Korisnik").Where
                                 (x => (string)x.Element("ID") == username.Text)
                                 select new
                                 {
                                     XMLkorisnik = x.Element("ID").Value,
                                     XMLpwd = x.Element("Lozinka").Value,
                                     XMLime = x.Element("Ime").Value
                                 };
                foreach (var x in selected_user)
                {
                    FromXML_user = x.XMLkorisnik;
                    FromXML_pwd = x.XMLpwd;
                    FromXML_ime = x.XMLime;
                }



            if (user == FromXML_user)
            {
                if(pwd == FromXML_pwd)
                {
                    MessageBox.Show("Uspjesna prijava");
                    Profil ulaz = new Profil();

                    PassInfo.Ime_korisnika = FromXML_ime;
                    PassInfo.Lozinka_korisnika = FromXML_pwd;
                    PassInfo.ID_korisnika = FromXML_user;

                    OcistiUnos();
                    this.Hide();
                    ulaz.Show();
                }
                else
                {
                    MessageBox.Show("Kriva lozinka!");
                }
            }
            else
            {
                MessageBox.Show("Krivi korisnik!");
                OcistiUnos();
            }
        }

        private void OcistiUnos()
        {
            username.Clear();
            password.Clear();
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Exit();
        }

        
    }
}
