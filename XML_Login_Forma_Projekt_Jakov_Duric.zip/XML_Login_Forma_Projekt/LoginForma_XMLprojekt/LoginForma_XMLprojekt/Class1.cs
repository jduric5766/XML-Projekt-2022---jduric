﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoginForma_XMLprojekt
{
    internal class PassInfo
    {
        public static string Ime_korisnika { get; set; }
        public static string ID_korisnika { get; set; }

        public static string Lozinka_korisnika { get; set; }
    }
}
